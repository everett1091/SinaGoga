#!/bin/bash
echo "Установка SinaGoga v1.0..."
mkdir -p /usr/local/bin
for file in bin/*; do
  cp "$file" /usr/local/bin/$(basename "$file")
  chmod +x /usr/local/bin/$(basename "$file")
done
echo "✅ Установка завершена. Используй команды: i, sudo pptp, sudo wifi и т.д."
