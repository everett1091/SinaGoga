#!/bin/bash
echo "Установка SinaGoga v1.0..."
mkdir -p /usr/local/bin
for cmd in i pptp wifi mac dns proxy stop cloak stunnel ss sshd ovpn wg ikev2 l2tp sstp ssh sshdirect; do
    cp bin/$cmd /usr/local/bin/$cmd
    chmod +x /usr/local/bin/$cmd
done
echo "✅ Установка завершена. Используйте команды типа 'sudo pptp', 'sudo wifi', 'i'"
