#!/bin/bash
echo 'Установка SinaGoga v1.0...'
