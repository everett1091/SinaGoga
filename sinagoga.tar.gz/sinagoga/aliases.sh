# alias commands like pptp, wifi, wg, etc.
