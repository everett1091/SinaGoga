#!/bin/bash
echo 'Введите токен для Telegram бота:'
read TOKEN
# Сохранить и запустить бота
