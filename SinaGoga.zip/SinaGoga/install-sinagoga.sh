#!/bin/bash
echo 'Installing SinaGoga...'
# Stub installer