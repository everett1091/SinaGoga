# SinaGoga

Custom Raspberry Pi CLI firmware installer.